$(document).ready(function() {
    $("h1").addClass("animated pulse");
   });
$(document).ready(function(){
  $("h2").addClass("animated fadein");
});
$(document).ready(function() {
  $(".intro-background").addClass("animated fadeInUp");
});